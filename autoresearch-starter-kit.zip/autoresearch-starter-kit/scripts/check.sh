#!/usr/bin/env bash
set -euo pipefail

node response-curves/train.js
node demand-forecast/train.js
