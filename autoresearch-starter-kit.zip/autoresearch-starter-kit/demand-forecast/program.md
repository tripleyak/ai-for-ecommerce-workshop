# Demand Forecast Autoresearch Program

Goal: improve holdout WMAPE for demand forecasting.

This track uses units sold, price, ad spend, and market signal history. The editable model should predict future demand.

## Files

- `prepare.js` - fixed evaluation harness. Do not edit.
- `train.js` - editable forecasting logic. This is the only file the agent edits.
- `data/sample.csv` - small workshop-safe sample data.
- `results.tsv` - experiment log.

## Metric

The script prints:

```text
portfolio_wmape: 0.123456
series_evaluated: 3
```

Lower `portfolio_wmape` is better.

## Allowed Ideas

- Moving averages and exponential smoothing.
- Trend models.
- Price and promo adjustments.
- Ad-spend or market-signal regressions.
- Seasonality features.
- Ensembles of simple forecasts.

## Rules

- Only edit `train.js`.
- Do not edit `prepare.js`.
- Do not edit `data/sample.csv`.
- Keep changes small and explainable.
- Log every experiment in `results.tsv`.
- Keep an experiment only if holdout WMAPE improves.
