# Autoresearch Starter Kit

This is a local workshop starter kit for building a Karpathy-inspired autoresearch loop on a MacBook.

It has two tracks:

1. `response-curves` - recreate the core idea behind ProfitCurve: fit spend-to-sales response curves and improve holdout WMAPE.
2. `demand-forecast` - create a demand planning forecast loop and improve holdout WMAPE.

The pattern is the same in both tracks:

- `program.md` explains the research task.
- `prepare.js` is the fixed evaluation harness. Do not edit it.
- `train.js` is the editable file. The AI agent modifies this file.
- `results.tsv` logs every experiment.
- The metric is holdout WMAPE. Lower is better.

## Quick Start

```bash
cd autoresearch-starter-kit
node response-curves/train.js
node demand-forecast/train.js
```

## Set Up Git For The Experiment Loop

```bash
git init
git add .
git commit -m "baseline autoresearch starter"
```

Only run destructive Git commands inside this starter folder.

## Agent Prompt

Use this in Codex or Claude Code from inside one track folder:

```text
Read program.md. Run the baseline. Then start an autoresearch loop.

Rules:
- Only edit train.js.
- Do not edit prepare.js or data files.
- After each idea, run node train.js.
- Log the result in results.tsv.
- Keep the change only if holdout WMAPE improves.
- If it gets worse, discard the train.js change and try a new idea.
- Prefer simple changes that improve the metric.
```

## Workshop Safety

Use the sample data first. If you bring your own data, remove account IDs, customer data, order IDs, credentials, and anything you would not show on a projector.
