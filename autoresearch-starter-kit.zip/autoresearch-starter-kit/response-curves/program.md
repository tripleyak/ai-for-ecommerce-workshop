# Response Curve Autoresearch Program

Goal: improve holdout WMAPE for spend-to-sales response curves.

This is the ProfitCurve-style track. Each product family has historical spend and sales data. The editable model should predict sales from spend.

## Files

- `prepare.js` - fixed evaluation harness. Do not edit.
- `train.js` - editable model and fitting logic. This is the only file the agent edits.
- `data/sample.csv` - small workshop-safe sample data.
- `results.tsv` - experiment log.

## Metric

The script prints:

```text
portfolio_wmape: 0.123456
families_evaluated: 3
```

Lower `portfolio_wmape` is better.

## Allowed Ideas

- Model types: linear, log, quadratic, saturation, piecewise.
- Weighting: recency weighting, inverse-sales weighting, spend weighting.
- Preprocessing: weekly aggregation, outlier removal, spend buckets.
- Selection: pick the best model by training WMAPE or validation split.
- Ensembles: blend top models when they are close.

## Rules

- Only edit `train.js`.
- Do not edit `prepare.js`.
- Do not edit `data/sample.csv`.
- Keep changes small and explainable.
- Log every experiment in `results.tsv`.
- Keep an experiment only if holdout WMAPE improves.
